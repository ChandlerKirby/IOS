//
//  ContentView.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 5/5/2022.
//

import SwiftUI

// default Web Image URL
let defaultImage = "https://bkimg.cdn.bcebos.com/pic/f31fbe096b63f624f8a0b88b8744ebf81b4ca3bd?x-bce-process=image/resize,m_lfit,w_220,limit_1/format,f_auto"

struct ContentView: View {
    
    @Binding var dbManager: DBManager
    // list need in a Navigation View with an editable title.   
    var body: some View {
        NavigationView {
            // creat PlaceListView 
            PlaceListView(dbManager: $dbManager)
                .navigationTitle("FavouritePlaces") // navigation bar Title
             // create left "+"   right "EditButton"
                .navigationBarItems(leading: Button("+", action: {
                    
                    // Creat PlaceModel
                   let newPlace = PlaceModel(id: UUID().uuidString, name: "NewPlace", image: defaultImage, long: "0", lat: "0")
                    // Add Place to Coredata
                   _ = dbManager.addPlace(placeModel: newPlace)
                }).frame(width: 30, height: 30, alignment: .center).font(Font.system(size: 30)), trailing: EditButton())
        }
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
