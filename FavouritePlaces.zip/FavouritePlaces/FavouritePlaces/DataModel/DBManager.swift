//
//  DBManager.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import Foundation
import CoreData
import UIKit

let entityName = "Place"
struct DBManager {
    typealias completionHandler = ((_ placeModelList:[PlaceModel]) -> Void)
    private var viewContext: NSManagedObjectContext
    var placeModelList = [PlaceModel]()
    static var share = DBManager()
    init(){
        // coradata set
        viewContext = PersistenceController.shared.container.viewContext
        // get coredata Place list
        self.queryAllPlace{ placeModelList in
            //default 3 city
            if placeModelList.count == 0{
                let citys = ["Sydney","Canberra","Brisbane"]
               
                for i  in 0..<citys.count {
                    let placeModel = PlaceModel(id: UUID().uuidString, name: citys[i], image: defaultImage, address: "", long: "0", lat: "0")
                   _ = self.addPlace(placeModel: placeModel)
                    
                }
                self.refreshData()
                
            }else{
                self.placeModelList = placeModelList
            }
         
        }
    }
    
    /**
     *  refresh for get new data
     *
     */
    mutating func refreshData()  {
        self.queryAllPlace{ placeModelList in
            self.placeModelList = placeModelList
         
        }
    }
    
    
    /**
     *  add one Place
     *  - Parameter completion query result callback
     */
    mutating func addPlace(placeModel:PlaceModel) -> Bool  {
        let newPlace = NSEntityDescription.insertNewObject(forEntityName: entityName, into: viewContext) as! Place
        // PlaceModel -> Place
        newPlace.setValues(placeModel: placeModel)
        do {
            // sandbox sync
            try viewContext.save()
            
            self.refreshData()
            return true
        } catch  {
            print("addPlace error")
            return false
        }
        
    }
    
    /**
     *  delete one Place
     *  - Parameter completion query result callback
     */
    mutating func deletePlace(atOffsets indices: IndexSet){
        indices.map{placeModelList[$0]}.forEach { placeModel in
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
            let predicate = NSPredicate(format: "id = %@", placeModel.id)
            fetchRequest.predicate = predicate
            do {
                if let resultList = try self.viewContext.fetch(fetchRequest) as? [Place]{
                    for result in resultList {
                        self.viewContext.delete(result)
                    }
                    try? self.viewContext.save()
                    self.refreshData()
                }
            } catch  {
                print(error)
            }
        }
      
    }
    /**
     *  get all Place
     *  - Parameter completion query result callback
     */
    func queryAllPlace(completion:completionHandler)  {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        do {
            let fetchResults = try self.viewContext.fetch(fetchRequest)  as? [Place]
            var placeModelList = [PlaceModel]()
            if let fetchResults =  fetchResults,
               fetchResults.count > 0{
                for i in 0..<fetchResults.count {
                    let fetchResult = fetchResults[i]
                    let placeModel = fetchResult.toPlaceModel()
                    placeModelList.append(placeModel)
                }
            }
            completion(placeModelList)
            print("queryPlace success")
        } catch  {
            print("queryPlace error")
            completion([PlaceModel]())
        }
    }
    /**
     *  update  one Place
     *  - Parameter completion query result callback
     */
    mutating func updatePlace(placeModel:PlaceModel){
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let predicate = NSPredicate(format: "id = %@", placeModel.id)
        fetchRequest.predicate = predicate
        do {
            if let resultList = try self.viewContext.fetch(fetchRequest) as? [Place]{
                for result in resultList {
                    result.setValues(placeModel: placeModel)
                }
                try? self.viewContext.save()
                self.refreshData()
            }
        } catch  {
            print(error)
        }
    }
}




extension Place {
    ///
    /// PlaceModel -> Place
    ///
    func setValues(placeModel: PlaceModel) {
        self.id = placeModel.id
        self.name = placeModel.name
        self.image = placeModel.image
        self.address = placeModel.address
        self.lat = Double(placeModel.lat) ?? 0
        self.long = Double(placeModel.long) ?? 0
        
    }
    
    ///
    /// Place -> PlaceModel
    ///
    func toPlaceModel() -> PlaceModel {
        var placeModel = PlaceModel()
        placeModel.id = self.id ?? UUID().uuidString
        placeModel.name = self.name ?? ""
        placeModel.image = self.image ?? ""
        placeModel.address = self.address ?? ""
        placeModel.lat = String(self.lat)
        placeModel.long =  String(self.long)
        
        return placeModel
        
    }
}
