//
//  Models.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import Foundation



struct PlaceModel:Identifiable {
    var id = UUID().uuidString
    var name = ""
    var image = ""
    var address = ""
    var long:String = "0"
    var lat:String = "0"
}
