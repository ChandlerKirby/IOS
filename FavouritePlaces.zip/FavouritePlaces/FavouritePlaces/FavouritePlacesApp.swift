//
//  FavouritePlacesApp.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 5/5/2022.
//

import SwiftUI

@main
struct FavouritePlacesApp: App {
    // create data
    @State var dbManager = DBManager.share
    var body: some Scene {
        WindowGroup {
            // Pass the required for binding group initialization
            ContentView(dbManager: $dbManager)
        }
    }
}
