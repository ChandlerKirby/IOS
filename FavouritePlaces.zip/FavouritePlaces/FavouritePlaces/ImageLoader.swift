//
//  ImageLoader.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import Foundation
import UIKit
///
/// Web image downLoader
///
class ImageLoader:ObservableObject {
    @Published var webImage: UIImage? = nil
    
    // get image
    public func getImage(url:String) -> UIImage? {
        if webImage == nil {
            downloadImage(url: url)
        }
        return webImage
    }
    // download  Image
    private func downloadImage(url: String){
        
        guard let imageURL = URL(string: url) else {
            return
        }
        //Download in the sub thread to prevent blocking the main thread
        DispatchQueue.global().async {
            // download web image
            if let data = try? Data(contentsOf: imageURL){
                DispatchQueue.main.async {
                    //UI set need in the  main thread
                    self.webImage = UIImage(data: data)
                }
            }
        }
        
    }
}
