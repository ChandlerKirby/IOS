//
//  MapDetailsView.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/19.
//

import SwiftUI
import MapKit
struct MapDetailsView: View {
    @Binding var placeModel:PlaceModel
    @Environment(\.editMode) var editMode
    // map show region
    @State private  var region: MKCoordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: -33, longitude: 151), span: MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.3))
    
    var body: some View {
        VStack(alignment: .center, spacing: 10) {
            if editMode?.wrappedValue == .active{
                Spacer().frame(height: 10)
                // on edit mode show search , CityNmae
                HStack(alignment: .center, spacing: 10){
                    Spacer().frame(width: 10)
                    Button {
                        self.lookupCoordinates()
                    } label: {
                        Image(systemName: "text.magnifyingglass")
                    }.frame(width: 30, height: 30, alignment: .center)
                    TextField("City Name", text: $placeModel.name){
                        self.lookupCoordinates()
                    }.frame(alignment: .leading)
                    
                    Spacer()
                }
                
            }
            Map(coordinateRegion: $region)
                .onChange(of: region, perform: { newPlace in
                    // new Region
                    if editMode?.wrappedValue == .active{
                        
                        placeModel.lat = String(newPlace.center.latitude)
                        placeModel.long = String(newPlace.center.longitude)
                    }
                    
                })
            // map frame
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 280, alignment: .top)
            
            if editMode?.wrappedValue == .active{
                //  edit coord TextField
                HStack(alignment: .center, spacing: 15) {
                    Spacer().frame(width: 15)
                    Button {
                        // click button search city by coord
                        self.lookupName()
                    } label: {
                        Image(systemName: "globe.europe.africa.fill")
                    }
                   
                    VStack(alignment: .center, spacing: 5){
                        HStack(alignment: .center, spacing: 10) {
                            Text("Latitude:")
                            TextField("latitude", text: $placeModel.lat){
                                // commit textfield and update map region
                                DispatchQueue.main.async {
                                    self.region = getNewRegion()
                                }
                                
                            }
                            .textFieldStyle(.roundedBorder)
                            
                        }
                        HStack(alignment: .center, spacing: 10) {
                            Text("Longitude:")
                            TextField("longitude", text: $placeModel.long){
                                // commit textfield and update map region
                                self.region = getNewRegion()
                            }
                            .textFieldStyle(.roundedBorder)
                        }
                    }
                }
                
                
                
            }else{
                Text("Latitude:\(placeModel.lat)")
                Text("Longitude:\(placeModel.long)")
            }
            Spacer()
        }
        .navigationTitle("Map of \(placeModel.name)" ) // navigation bar
        .navigationBarItems(trailing: EditButton())
        .onAppear{
            self.region = getNewRegion()
        }.onDisappear {
            // View will Disappear save data
            DBManager.share.updatePlace(placeModel: placeModel)
        }
    }
    
    /**
     *  get latest map  region
     *  - Returns: MKCoordinateRegion
     */
    func getNewRegion() -> MKCoordinateRegion{
        guard let lat = Double(self.placeModel.lat),
              let long = Double(self.placeModel.long),
              lat >= -90,
              lat <= 90,
              long >= -180,
              long <= 190 else{
            return region
        }
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.3))
        
    }
    
    /**
     *  search city to  location(coordinate)
     */
    func lookupCoordinates()  {
        LocationViewModel.share.lookupCoordinates(for: placeModel.name) { location in
            if let new = location{
                placeModel.lat = String(new.coordinate.latitude)
                placeModel.long = String(new.coordinate.longitude)
                region = MKCoordinateRegion(center: new.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.3))
            }
        }
    }
    /**
     *  search location to   city
     */
    
    func lookupName()  {
        if let latitude = Double(placeModel.lat),
           let longitude = Double(placeModel.long),
           latitude >= -90,
           latitude <= 90,
           longitude >= -180,
           longitude <= 190{
            let location = CLLocation(latitude: latitude, longitude: longitude)
            LocationViewModel.share.lookupName(for: location) { name in
                if let new = name {
                    placeModel.name = new
                }
            }
        }
        
    }
}


///
///  map loaction change must implementation equatable protocol
///
extension MKCoordinateRegion : Equatable{
    public static func == (lhs: MKCoordinateRegion, rhs: MKCoordinateRegion) -> Bool {
        return (lhs.center.latitude == rhs.center.latitude) && (lhs.center.longitude == rhs.center.longitude)
    }
    
    
}
//struct MapDetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        MapDetailsView()
//    }
//}
