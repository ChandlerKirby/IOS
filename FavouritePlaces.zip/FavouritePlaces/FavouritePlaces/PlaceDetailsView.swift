//
//  PlaceDetailsView.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import SwiftUI
import MapKit
struct PlaceDetailsView: View {
    @Binding var placeModel:PlaceModel
    @State var isEditMode: EditMode = .inactive
    //default image
    let placeholderOne = UIImage(named: "placeholder")! //
    @ObservedObject private var loader = ImageLoader.init()
    @State private  var region: MKCoordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 0, longitude: -0), span: MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.3))
    @State private var sunriseSunset = SunriseSunset(sunrise: "unknown", sunset: "unknown")
    var body: some View {
        VStack{
            List{
                //1
                if isEditMode == .active{
                    // When editing show City , URL,Location Details TextField
                    TextField("City", text: $placeModel.name)
                    TextField("Enter Image URL", text: $placeModel.image)
                    VStack(alignment: .center, spacing: 5) {
                        Text("Enter Location Details:")
                        TextField("Enter Location Details", text: $placeModel.address)
                    }
                }else{
                    // When no editing show image,address,
                    Image(uiImage: loader.getImage(url: placeModel.image) ?? placeholderOne)
                        .resizable()
                        .scaledToFit()
                        .frame(minWidth: nil, idealWidth: nil, maxWidth: UIScreen.main.bounds.width, minHeight: nil, idealHeight: nil, maxHeight: 150, alignment: .center)
                        .clipped()
                    NavigationLink {
                        MapDetailsView(placeModel: $placeModel)
                    } label: {
                        HStack(alignment: .center, spacing: 10) {
                            // preview map
                            Map(coordinateRegion: $region)
                                .frame(width:50, height: 50, alignment:.top)
                                .allowsHitTesting(false)
                            Spacer()
                            Text("Map of \(placeModel.name)")
                        }
                    }
                    Text(placeModel.address)
                    
                    
                }
                
                
            }
            if isEditMode != .active{
                Spacer()
                HStack(alignment: .center, spacing: 10) {
                    Label(sunriseSunset.sunrise, systemImage: "sunrise")
                    Spacer()
                    Label(sunriseSunset.sunset,  systemImage: "sunset")
                    
                }
            }
        }
        
        .navigationTitle(placeModel.name) // navigation bar Title title
        .navigationBarItems(trailing:Button(isEditMode.isEditing ? "Done":"Edit", action: {
            // click Edit or Done Btn
            
            switch isEditMode {
            case .active:
                // editing -> no editing
                DispatchQueue.main.async {
                    self.isEditMode = .inactive
                }
                
            case .inactive:
                // no editing ->  editing
                DispatchQueue.main.async {
                    self.isEditMode = .active
                }
            default:
                break
            }
            //when editing ,user click Done save coredata
            if self.isEditMode == .inactive {
                DBManager.share.updatePlace(placeModel: placeModel)
            }
            
        }))
        .onAppear(perform: {
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.region = getNewRegion()
            }
            self.lookupSunriseAndSunset()
            
        })
        .onDisappear(perform: {
            // View will Disappear save data
            DBManager.share.updatePlace(placeModel: placeModel)
        })
        .environment(\.editMode, self.$isEditMode)
    }
    
    /**
     *  get latest map  region
     *  - Returns: MKCoordinateRegion
     */
    func getNewRegion() -> MKCoordinateRegion{
        guard let lat = Double(self.placeModel.lat),
              let long = Double(self.placeModel.long),
              lat >= -90,
              lat <= 90,
              long >= -180,
              long <= 190 else{
            return region
        }
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.3, longitudeDelta: 0.3))
        
    }
    
    /**
     *  look city SunriseAndSunset
     *  
     */
    func lookupSunriseAndSunset()  {
        if let latitude = Double(placeModel.lat),
          let longitude = Double(placeModel.long){
            let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            LocationViewModel.share.lookupSunriseAndSunset(coordinate: coordinate) { sunriseSunset in
                if let new = sunriseSunset {
                    DispatchQueue.main.async {
                        self.sunriseSunset = new
                    }
                    
                }
            }
        }
    }
}

//struct PlaceDetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        PlaceDetailsView()
//    }
//}
