//
//  PlaceListRow.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import SwiftUI

struct PlaceListRowView: View {
    var placeModel:PlaceModel
    //default image
    let placeholderOne = UIImage(named: "placeholder")! //
    @ObservedObject private var loader = ImageLoader.init()
    // List if row content
    var body: some View {
        HStack(){
            Image(uiImage: loader.getImage(url: placeModel.image) ?? placeholderOne)
                .resizable()
                .aspectRatio(contentMode: .fill) // image Ratio fill
                .frame(width: 60, height: 60)
                .clipped() // clipped exceeded
            Text(placeModel.name)
        }
       
    }
}

//struct PlaceListRow_Previews: PreviewProvider {
//    static var previews: some View {
//        PlaceListRowView()
//    }
//}
