//
//  PlaceListView.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/5/11.
//

import SwiftUI

struct PlaceListView: View {
    @Binding var dbManager: DBManager
    var body: some View {
        // the Master View displays a list of (any number) of places
        List{
            ForEach(0..<dbManager.placeModelList.count,id: \.self){
                index in
                //Each item is embedded in a Navigation Link that allows the user to get to a Detail View by clicking (tapping) on the list item
                NavigationLink(destination: PlaceDetailsView(placeModel: $dbManager.placeModelList[index])) {
                    // List row
                    PlaceListRowView(placeModel: dbManager.placeModelList[index])
                }
            }// can delete when edit or left slip
            .onDelete(perform: { indexSet in
                dbManager.deletePlace(atOffsets: indexSet)
                
            })
            
        }
    }
}

//struct PlaceListView_Previews: PreviewProvider {
//    static var previews: some View {
//        PlaceListView()
//    }
//}
