//
//  SunriseSunset.swift
//  FavouritePlaces
//
//  Created by 彭佳林 on 2022/6/1.
//

import Foundation


struct SunriseSunset: Codable {
    var sunrise: String
    var sunset: String
}

struct SunriseSunsetAPI: Codable {
    var results: SunriseSunset
    var status: String?
}
