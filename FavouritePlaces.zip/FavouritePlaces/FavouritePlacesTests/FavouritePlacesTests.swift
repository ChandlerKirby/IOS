//
//  FavouritePlacesTests.swift
//  FavouritePlacesTests
//
//  Created by 彭佳林 on 5/5/2022.
//

import XCTest
import CoreData
@testable import FavouritePlaces

class FavouritePlacesTests: XCTestCase {
  let viewContext = PersistenceController.shared.container.viewContext
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        //1 delete
        delteAllPlace()
        
        //2 add
        let placeModel1 = PlaceModel(id: UUID().uuidString, name: "Canberra", image: "", address: "in center", long: "0", lat: "0")
       _ =  DBManager.share.addPlace(placeModel: placeModel1)
        DBManager.share.queryAllPlace { placeModelList in
            XCTAssertEqual(placeModelList.count, 1)
            XCTAssertEqual(placeModelList.first?.name, "Canberra")
        }
        
        let placeModel2 = PlaceModel(id: UUID().uuidString, name: "Brisbane", image: "", address: "in center", long: "0", lat: "0")
       _ =  DBManager.share.addPlace(placeModel: placeModel2)
        var placeModel3 = PlaceModel(id: UUID().uuidString, name: "Sydney", image: "", address: "in center", long: "0", lat: "0")
       _ =  DBManager.share.addPlace(placeModel: placeModel3)
        
        DBManager.share.queryAllPlace { placeModelList in
            XCTAssertEqual(placeModelList.count, 3)
        }
        
        //3 edit
        placeModel3.address = "Near the city basketball stadium"
        DBManager.share.updatePlace(placeModel: placeModel3)
        DBManager.share.queryAllPlace { placeModelList in
            var placeModelTemp = PlaceModel()
            for (_,placeModel) in placeModelList.enumerated() where placeModel.name == placeModel3.name{
                placeModelTemp = placeModel
            }
            XCTAssertEqual(placeModelTemp.address, placeModel3.address)
        }
        
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func delteAllPlace()  {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        print("delete all place")
        do {
            if let resultList = try self.viewContext.fetch(fetchRequest) as? [Place]{
                resultList.forEach{self.viewContext.delete($0)}
                try? self.viewContext.save()
                
            }
        } catch  {
            print(error)
        }
    }

}
