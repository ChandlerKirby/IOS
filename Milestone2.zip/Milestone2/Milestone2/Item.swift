//
//  Item.swift
//  Milestone2
//
//  Created by 彭佳林 on 10/4/2022.
//

import Foundation
import SwiftUI

struct Item {
    var name: String
    var isChecked: Bool
}
