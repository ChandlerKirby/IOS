//
//  Milestone2App.swift
//  Milestone2
//
//  Created by 彭佳林 on 9/4/2022.
//

import SwiftUI

@main
struct Milestone2App: App {
    @State var viewModel = CheckListViewModel()
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: $viewModel)
        }
    }
}
