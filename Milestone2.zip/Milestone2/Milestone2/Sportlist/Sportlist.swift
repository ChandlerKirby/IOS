//
//  Sportlist.swift
//  Checklist
//
//  Created by 彭佳林 on 31/3/2022.
//

let sports = ["Basketball",
              "Football",
              "Tennis",
              "Swimming"]
//create sports list
//use the tick to simulate the checkmark
