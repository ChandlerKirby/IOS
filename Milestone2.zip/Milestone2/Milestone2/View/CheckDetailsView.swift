//
//  CheckDetailsView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckDetailsView: View {
    @Binding  var checkModel : CheckModel
    @Environment(\.editMode) var editMode
    @State var titleString = ""
    @State var title = ""
    @State var detailsViewModel = CheckDetailsViewModel()
    @State var isChecked = false
    
    @State var str = "1222"
    var body: some View {
        List{
            if editMode?.wrappedValue == .active {
                //when edit status show title edit
                HStack(alignment: .center){
                    Image(systemName: "square.and.pencil")
                        .frame(width: 30, height: 30, alignment: .leading)
                    //$checkModel.title
                    TextField("input title", text: $titleString)
                        .font(Font.system(size: 24))
                        .background(Color.clear)
                    
                }
            }
            ForEach($detailsViewModel.checkDetailsModelList, id: \.self) { detailsModel in
                
                CheckDetailsRowView(detailsModel: detailsModel)
                   
            }
            .onDelete { indexSet in
                detailsViewModel.remove(atOffsets: indexSet)
            }
           // when edit status  the row can add new data
            if editMode?.wrappedValue == .active {
                HStack {
                    Image(systemName: "plus.circle").foregroundColor(.green)
                    TextField("Enter new entry name:", text: $title) {
                        detailsViewModel.checkDetailsModelList.append(CheckDetailsModel(title: title ,isSel: false))
                        title = ""
                    }
                }
                
            }
            
        }
        //when edit status no show title  otherwise  show title
        //
        .onAppear(perform: {
            titleString = checkModel.title
        })
        .navigationBarTitle(editMode?.wrappedValue == .active ? "" : titleString)
        .navigationBarTitleDisplayMode(.large)
        .navigationBarItems(trailing: HStack(alignment: .center){
           if self.editMode?.wrappedValue == EditMode.active {
               // reset button
                Button {
                    self.isChecked.toggle()
                    for (index,_) in detailsViewModel.checkDetailsModelList.enumerated() {
                        //Check and undoCheck
                        detailsViewModel.checkDetailsModelList[index].isSel = !self.isChecked
                    }
                } label: {
                    Text(self.isChecked ? "Undo Reset":"Reset")
                }
               Spacer()
           }
            //edit button
           
            EditButton()
        })
    
    }
        
}

//struct CheckDetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        CheckDetailsView(checkModel: Binding.constant(CheckModel(title: "CheckList")))
//    }
//}
