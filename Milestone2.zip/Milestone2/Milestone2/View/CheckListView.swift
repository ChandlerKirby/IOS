//
//  CheckListView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckListView: View {
    @Binding var viewModel: CheckListViewModel
    //@Environment(\.editMode) var editMode
    @State var title = ""
    var body: some View {
        List{
            ForEach($viewModel.checkModelList, id: \.self) { checkModel in
                //destination : DetailsView
                NavigationLink(destination: CheckDetailsView(checkModel: checkModel)) {
                    // row
                    CheckRowView(checkModel: checkModel)
                }
                
            }
            // allow editStatus show delete button
            .onDelete { itemNumbers in
                
                viewModel.remove(atOffsets: itemNumbers)
            }

            
        }
    }
}

struct CheckListView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(viewModel: Binding.constant(CheckListViewModel()))
    }
}
