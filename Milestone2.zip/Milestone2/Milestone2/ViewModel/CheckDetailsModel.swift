//
//  CheckDetailsModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckDetailsModel: Hashable {
    var title : String
    var isSel: Bool = false
}


