//
//  CheckDetailsViewModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import Foundation
struct CheckDetailsViewModel {
    var checkDetailsModelList = [CheckDetailsModel]()
    init() {
        for (_,item) in sports.enumerated() {
            checkDetailsModelList.append(CheckDetailsModel(title: item,isSel: false))
        }
        
    }
    mutating func addElement(detailsModel:CheckDetailsModel) {
        
        checkDetailsModelList.append(detailsModel)
    }

    mutating func remove(atOffsets indices: IndexSet) {
        checkDetailsModelList.remove(atOffsets: indices)
    }
}
