//
//  ItemListViewModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 10/4/2022.
//

import Foundation

struct CheckListViewModel {
    var checkModelList = [CheckModel]()
    init() {
        checkModelList.append(CheckModel(title: "Sport"))
    }
    mutating func addElement(checkModel:CheckModel) {
        
        checkModelList.append(checkModel)
    }

    mutating func remove(atOffsets indices: IndexSet) {
        checkModelList.remove(atOffsets: indices)
    }
}

