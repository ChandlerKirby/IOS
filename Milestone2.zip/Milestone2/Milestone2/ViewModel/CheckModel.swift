//
//  ItemFileModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 10/4/2022.
//

import Foundation
import SwiftUI

struct CheckModel:Hashable {
      var title : String
}
