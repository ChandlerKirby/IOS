//
//  CheckDetailsRowView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckDetailsRowView: View {
    @Binding var detailsModel :CheckDetailsModel
    var body: some View {
        Button {
            // selector button
            detailsModel.isSel.toggle()
            CheckListViewModel.save()
        } label: {
            HStack(alignment: .center, spacing: 10) {
                Text(detailsModel.title)
                Spacer()
                if detailsModel.isSel {
                    Image(systemName: "checkmark")
                }
            }
        }

    }
}

//struct CheckDetailsRowView_Previews: PreviewProvider {
//    static var previews: some View {
//        CheckDetailsRowView(detailsModel: Binding.constant(CheckDetailsModel(title: "Basketball",isSel: false)))
//    }
//}
