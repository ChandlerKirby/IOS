//
//  CheckDetailsView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckDetailsView: View {
    
    @Binding  var checkModel : CheckModel
    @Environment(\.editMode) var editMode
    @State var title = ""
    @State var isChecked = false
    
    var body: some View {
        List{
            if editMode?.wrappedValue == .active {
                //when edit status show title edit
                HStack(alignment: .center){
                    Image(systemName: "square.and.pencil")
                        .frame(width: 30, height: 30, alignment: .leading)
                    //$checkModel.title
                    TextField("input title", text: $checkModel.title,onCommit: {
                        CheckListViewModel.save()
                    })
                        .font(Font.system(size: 24))
                        .background(Color.clear)
                    
                }
            }
            ForEach($checkModel.checkDetailsList) { detailsModel in
                
                CheckDetailsRowView(detailsModel: detailsModel)
                   
            }
            .onMove(perform: { indexSet, index in
                // when move change of position
                checkModel.checkDetailsList.move(fromOffsets: indexSet, toOffset: index)
                CheckListViewModel.save()
            })
            .onDelete { indexSet in
                checkModel.checkDetailsList.remove(atOffsets: indexSet)
                CheckListViewModel.save()
            }
           // when edit status  the row can add new data
            if editMode?.wrappedValue == .active {
                HStack {
                    Image(systemName: "plus.circle").foregroundColor(.green)
                    TextField("Enter new entry name:", text: $title) {
                        checkModel.checkDetailsList.append(CheckDetailsModel(id: UUID(), title: title, isSel: false))
                        CheckListViewModel.save()
                        title = ""
                    }
                }
                
            }
            
        }
        //when edit status no show title  otherwise  show title
        .navigationBarTitle(editMode?.wrappedValue == .active ? "" : checkModel.title)
        .navigationBarTitleDisplayMode(.large)
        .navigationBarItems(trailing: HStack(alignment: .center){
           if self.editMode?.wrappedValue == EditMode.active {
               // reset button
                Button {
                    self.isChecked.toggle()
                    for (index,_) in checkModel.checkDetailsList.enumerated() {
                        //Check and undoCheck
                        checkModel.checkDetailsList[index].isSel = !self.isChecked
                    }
                    CheckListViewModel.save()
                } label: {
                    Text(self.isChecked ? "Undo Reset":"Reset")
                }
               Spacer()
           }
            //edit button
           
            EditButton()
        })
    
    }
        
}

//struct CheckDetailsView_Previews: PreviewProvider {
//    static var previews: some View {
//        CheckDetailsView(checkModel: Binding.constant(CheckModel(title: "CheckList")))
//    }
//}
