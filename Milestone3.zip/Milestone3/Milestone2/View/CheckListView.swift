//
//  CheckListView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckListView: View {
    @Binding var viewModel: CheckListViewModel
    //@Environment(\.editMode) var editMode
    var body: some View {
        List{
            
            ForEach($viewModel.checkModelList) { checkModel in
                //destination : DetailsView
                NavigationLink(destination: CheckDetailsView(checkModel:checkModel )) {
                    // row
                    CheckRowView(checkModel: checkModel)
                }
                
            }
            // move item
            .onMove(perform: { indexSet, index in
                viewModel.move(fromOffsets: indexSet, toOffset: index)
            })
            // allow editStatus show delete button
            .onDelete { itemNumbers in
                viewModel.remove(atOffsets: itemNumbers)
            }

            
        }
    }
}

//struct CheckListView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView(viewModel: Binding.constant(CheckListViewModel()))
//    }
//}
