//
//  CheckRowView.swift
//  Milestone2
//
//  Created by 彭佳林 on 2022/4/10.
//

import SwiftUI

struct CheckRowView: View {
    @Binding var checkModel : CheckModel
    var body: some View {
        Text(checkModel.title)
    }
}

//struct CheckRowView_Previews: PreviewProvider {
//    static var previews: some View {
//        CheckRowView(checkModel: Binding.constant(CheckModel(title: "CheckList")))
//    }
//}
