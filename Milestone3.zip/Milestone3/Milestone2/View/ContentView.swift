//
//  ContentView.swift
//  Milestone2
//
//  Created by 彭佳林 on 9/4/2022.
//

import SwiftUI

struct ContentView: View {
    @Binding var viewModel: CheckListViewModel
    var body: some View {
        NavigationView{
            CheckListView(viewModel: $viewModel)
                .navigationTitle("CheckList")
            // left(edit) right(+)
                .navigationBarItems(leading: EditButton(), trailing: Button(action: {
                    // andom value
                    let num = arc4random_uniform(100)
                    let model = CheckModel(id: UUID(), title: "CheckList " + String(num), checkDetailsList: [CheckDetailsModel]())
                    // add
                    viewModel.addElement(checkModel:model)
                }, label: {
                    Text("+").font(Font.system(size: 30))
                }))
        }
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView(viewModel: Binding.constant(CheckListViewModel()))
//    }
//}
