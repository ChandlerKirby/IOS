//
//  ItemListViewModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 10/4/2022.
//

import Foundation
import SwiftUI

struct CheckListViewModel:Codable,Identifiable {
    var id = UUID()
    // all data
    var checkModelList:[CheckModel] = [CheckModel]()
  
    init() {
        if let data  = try? Data(contentsOf: CheckListViewModel.fileURL),
           let model = try? JSONDecoder().decode([CheckModel].self, from: data) ,
           model.count > 0{
            checkModelList = model
        }else{
            //default data
            var checkDetailsModelList = [CheckDetailsModel]()
            for (_,item) in sports.enumerated() {
                checkDetailsModelList.append(CheckDetailsModel(id: UUID(), title: item, isSel: false))
            }
            self.checkModelList = [CheckModel(id: UUID(), title: "Sport", checkDetailsList: checkDetailsModelList)]
        }
        
    }
    mutating func addElement(checkModel:CheckModel) {
        
        checkModelList.append(checkModel)
        CheckListViewModel.save()
    }
    
    mutating func remove(atOffsets indices: IndexSet) {
        checkModelList.remove(atOffsets: indices)
        CheckListViewModel.save()
    }
    
    mutating func move(fromOffsets: IndexSet, toOffset: Int){
        checkModelList.move(fromOffsets: fromOffsets, toOffset: toOffset)
        CheckListViewModel.save()
    }
    //save 头 sandbox
    static func save() {
        do {
            let data = try JSONEncoder().encode(Milestone2App.viewModelBinding?.wrappedValue.checkModelList ?? [CheckModel]())
            try data.write(to:CheckListViewModel.fileURL, options: .atomic)
            //            guard let dataString = String(data: data, encoding: .utf8) else { return }
            //            print(dataString)
        } catch {
            print("Could not write file: \(error)")
        }
    }
    
    //save sandbox path
    static var fileURL: URL = {
        let fileName = "persons.json"
        let fm = FileManager.default
        guard let documentDir = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "/") }
        let fileURL = documentDir.appendingPathComponent(fileName)
        print(documentDir)
        return fileURL
    }()
    
}

