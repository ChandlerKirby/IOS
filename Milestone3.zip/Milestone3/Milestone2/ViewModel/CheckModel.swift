//
//  ItemFileModel.swift
//  Milestone2
//
//  Created by 彭佳林 on 10/4/2022.
//

import Foundation
import SwiftUI

struct CheckModel:Codable,Identifiable {
    var id = UUID()
    var title : String
    var checkDetailsList:[CheckDetailsModel] //@Binding
}


struct CheckDetailsModel: Codable,Identifiable {
    var id = UUID()
    var title : String
    var isSel: Bool = false
}
