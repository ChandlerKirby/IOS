//
//  Milestone2Tests.swift
//  Milestone2Tests
//
//  Created by 彭佳林 on 9/4/2022.
//

import XCTest
@testable import Milestone2

class Milestone2Tests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testsportname() throws {
        let sport3 = "Tennis"
        XCTAssertEqual(sport3, "Tennis")
        
        var viewModel = CheckListViewModel()
        let checkModelOne =  CheckModel(id: UUID(), title: "CheckList99", checkDetailsList: [CheckDetailsModel]())
        viewModel.checkModelList.append(checkModelOne)
        
        XCTAssertEqual(viewModel.checkModelList.last?.checkDetailsList.count, 0)
        
        
        var checkDetailsModelList = [CheckDetailsModel]()
        for (_,item) in sports.enumerated() {
            checkDetailsModelList.append(CheckDetailsModel(id: UUID(), title: item, isSel: false))
        }
        XCTAssertEqual(checkDetailsModelList[0].title, "Basketball")
        
        XCTAssertEqual(checkDetailsModelList.last?.title, "Swimming")
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
